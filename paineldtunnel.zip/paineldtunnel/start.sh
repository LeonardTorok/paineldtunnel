#!bin/bash
GREEN='\033[0;32m'
while : 
do
echo "iniciando no modo anti queda aguarde..."
    npm run dev
    sleep 1

done
